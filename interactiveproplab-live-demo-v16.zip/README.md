# Interactive Prop Lab — live demo v16

v16 fixes an incorrect dependency pin in v14/v15.

The current official MediaPipe web sample lockfile resolves:

- `@mediapipe/tasks-vision` **1.0.0**
- Vite **8.1.5**

v15 incorrectly used Tasks Vision 1.0.1.

v16 pins the exact current official versions and keeps the same layout,
calibration, LED matrix, same-origin WASM/model deployment, worker architecture,
and one-frame-at-a-time webcam loop.

## Startup diagnostics

The worker now reports each initialization stage to the browser console:

- worker running
- resolving WASM fileset
- WASM fileset resolved
- loading face model
- face model loaded
- creating Face Landmarker task
- Face Landmarker task created

If initialization exceeds 30 seconds, the visible error includes the last stage,
for example:

`Face tracker initialization timed out at: creating Face Landmarker task`

That removes the opaque timeout from v15.

## Deploy

Same as v15:

1. Replace the repository contents with this project.
2. GitHub → Settings → Pages → Source: GitHub Actions.
3. Push to `main`.
4. Let the included workflow build and deploy.

Pinned:
- `@mediapipe/tasks-vision` 1.0.0
- Vite 8.1.5
