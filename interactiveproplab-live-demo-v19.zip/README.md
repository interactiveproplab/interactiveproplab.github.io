# Interactive Prop Lab — live demo v19

v19 keeps the tracker architecture, calibration, LED matrix, and visible layout
from the working Chromium build.

## Startup resilience

Tracker initialization is now retried automatically:

- up to 3 attempts;
- 10 second timeout per attempt;
- the old worker is fully terminated between attempts;
- each retry creates a fresh worker and fresh MediaPipe runtime;
- a short 250 ms pause separates attempts.

This targets the intermittent case where the exact same deployed build sometimes
initializes and tracks correctly, and sometimes hangs during worker/WASM startup.

## User-facing failure message

If all attempts fail, the demo reports:

`Facial landmarking source unavailable.`

The message also includes the final initialization stage and error so the failure
is distinguishable from camera permission problems.

Detector/runtime failures no longer imply that the webcam itself is unavailable.

## Browser compatibility

Firefox-family browsers, including LibreWolf, receive:

`Facial landmarking source unavailable in this browser. For best compatibility,
open the live demo in a Chromium-based browser.`

Footer text now reads:

`Facial landmark inference runs on-device with MediaPipe. For best compatibility,
use a Chromium-based browser. MediaPipe may send SDK performance and usage metrics
to Google.`

## Deploy

Replace the repository contents with v19 and push to `main`.
Keep GitHub Pages configured for GitHub Actions.
