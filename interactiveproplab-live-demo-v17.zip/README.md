# Interactive Prop Lab — live demo v17

v17 fixes the broken v16 loader URL.

## Critical fix

v15/v16 manually mutated MediaPipe's resolved WASM loader URL to append:

`?cb=<timestamp>`

That was not required by the current official worker and caused failures such as:

`Failed to fetch dynamically imported module: /wasm/vision_wasm_module_internal.js?cb=...`

v17 removes that mutation entirely.

The runtime is now:

- `@mediapipe/tasks-vision` 1.0.0
- same-origin package WASM copied during build
- same-origin `face_landmarker.task`
- module worker
- `createImageBitmap(video)`
- `detectForVideo(bitmap, timestampMs)`
- CPU delegate

## Browser handling

Firefox-family browsers (including LibreWolf) now get a clean compatibility
message before tracker initialization.

Chromium-based browsers remain the supported live-demo path.

## Error handling

Detector errors no longer stop the webcam. The camera remains visible while the
tracking error is reported, so a detector failure cannot masquerade as a camera
failure.

## Deploy

Replace the repository contents with this project, then push to `main`.
GitHub Pages should remain configured to deploy with GitHub Actions.
