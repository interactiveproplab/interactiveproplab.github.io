# Interactive Prop Lab — live demo v13

v13 keeps:
- the working v11 detector architecture;
- the v12 calibration improvements;
- the v12 visible 64×32 LED matrix;
- the good v7 layout.

Upload:
- `index.html`
- `style.css`
- `face-demo-v13.js`

## Inference stability changes

The previous build could fail with a MediaPipe internal:
`index out of bounds`

v13 changes only inference lifecycle:

- removes the 64×64 blank startup probe;
- waits for the actual webcam dimensions;
- chooses one detector frame size (max 640px wide) and keeps it fixed for the session;
- uses even processing dimensions;
- still sends only `ImageData` into Face Landmarker;
- one bad inference frame is dropped instead of killing the demo;
- after four consecutive detector errors, Face Landmarker is recreated automatically;
- calibration is reset after detector recovery.

The visible layout, LED output and calibration tuning from v12 remain.
