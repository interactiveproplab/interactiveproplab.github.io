# Interactive Prop Lab — live demo v12

v12 keeps the working v11 detector and the good overall v7/v11 layout.

Upload:

- `index.html`
- `style.css`
- `face-demo-v12.js`

## Changes

Detector/runtime: unchanged from v11.

Calibration:
- 1.6 second calibration window;
- first 350 ms ignored while tracking settles;
- at least six valid samples required;
- median baseline instead of mean;
- neutral eye openness maps to ~0.72 instead of 1.0;
- brow, gaze and mouth-curvature gains are less aggressive.

LED output:
- removed the asymmetric oval output container;
- clear rectangular 64×32 matrix;
- every physical LED position is visible as a dim red dot;
- active face LEDs are bright coral circles with a small glow.

The rest of the page structure/layout is unchanged.
