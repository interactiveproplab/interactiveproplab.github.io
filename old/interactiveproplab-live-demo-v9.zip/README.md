# Interactive Prop Lab — live demo v9

v9 starts from the good v7 layout.

Upload:

- `index.html`
- `style.css`
- `face-demo-v9.js`

Delete every older `face-demo-v*.js` and `face-worker-v*.js`.

## Detector architecture

The visible layout is unchanged from v7.

The detector now uses TensorFlow.js Face Landmarks Detection on the WASM backend:

- TensorFlow.js Core 4.22.0
- TensorFlow.js Converter 4.22.0
- TensorFlow.js WASM backend 4.22.0
- TensorFlow Models Face Detection 1.0.3
- TensorFlow Models Face Landmarks Detection 1.0.6
- runtime: `tfjs`
- refineLandmarks: `true`
- 478 keypoints

The page does not load the TensorFlow.js WebGL backend.

Before the model is created, the code forces:

`tf.setBackend("wasm")`

and verifies that `tf.getBackend()` actually returns `wasm`.

This removes the WebGL runtime path that caused the repeated browser failures.
The v7 camera/input layout and 64×32 protogen output matrix are unchanged.
