# Interactive Prop Lab — live demo v7

This is a layout-only correction on top of the v6 Face Mesh detector.

Upload:

- `index.html`
- `style.css`
- `face-demo-v7.js`

Delete older `face-demo-v*.js`.

## What changed

Tracking logic is unchanged from v6.

The demo structure is now deliberately rigid:

- headline and explanatory copy are a separate block above the demo;
- webcam lives inside a normal 16:9 monitor box in the left card;
- the webcam cannot become a section/background layer;
- tracking overlay is positioned only inside that camera viewport;
- simulated protogen LED matrix is a separate right card;
- desktop flow is CAMERA → TRACK → PROTOGEN;
- mobile flow stacks cleanly without overlapping the title.

The output visor is visually shaped like a protogen face rather than a bare rectangular canvas.
