import pytest

from protogen_tracker.models import ExpressionState


def test_default_state_is_valid():
    state = ExpressionState()
    assert state.tracking_valid is False


def test_unit_range_is_enforced():
    with pytest.raises(ValueError):
        ExpressionState(left_eye_open=1.1)


def test_signed_range_is_enforced():
    with pytest.raises(ValueError):
        ExpressionState(gaze_x=-1.1)
