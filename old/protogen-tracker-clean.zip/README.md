# Protogen Tracker

Generic live facial-expression tracking for protogen control systems.

This repo contains only the tracking core:

```text
camera / video
      ↓
MediaPipe Face Landmarker
      ↓
neutral calibration
      ↓
normalised ExpressionState
```

There is no renderer, no character-specific animation, and no Vox-specific code.

## Output state

`ExpressionState` exposes:

- left/right eye openness
- gaze X/Y
- left/right brow height
- left/right brow tilt
- mouth opening
- mouth width
- mouth roundness
- mouth compression
- mouth curvature
- tracking-valid state
- measurement timestamp

## Setup

Python 3.11+.

```bash
python -m venv .venv
```

Linux/macOS:

```bash
source .venv/bin/activate
```

Windows PowerShell:

```powershell
.venv\Scripts\Activate.ps1
```

Install:

```bash
pip install -e .
```

## MediaPipe model

Create:

```text
models/
```

and put a MediaPipe Face Landmarker `.task` model at:

```text
models/face_landmarker.task
```

The model is intentionally not included.

## Run

Webcam:

```bash
protogen-tracker --camera 0
```

or:

```bash
python -m protogen_tracker --camera 0
```

Prerecorded demo video:

```bash
protogen-tracker --video face-demo.mp4
```

For prerecorded video, begin with roughly one second of a neutral face. That first second becomes the calibration baseline.

## Project layout

```text
protogen-tracker/
├── config.toml
├── pyproject.toml
├── README.md
├── src/
│   └── protogen_tracker/
│       ├── __init__.py
│       ├── __main__.py
│       ├── cli.py
│       ├── config.py
│       ├── models.py
│       ├── terminal.py
│       └── tracker.py
└── tests/
    └── test_models.py
```

## Next step

Keep the tracker generic.

Character-specific behaviour should be a separate layer later:

```text
ExpressionState
      ↓
CharacterMapper
      ↓
display / hardware outputs
```
