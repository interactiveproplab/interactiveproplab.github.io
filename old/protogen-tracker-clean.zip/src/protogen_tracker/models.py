from __future__ import annotations

from dataclasses import dataclass
from math import isfinite


@dataclass(frozen=True, slots=True)
class ExpressionState:
    """Renderer-independent facial state.

    0..1:
        eye openness, mouth opening/width/roundness/compression

    -1..1:
        gaze, brow height/tilt, mouth curvature
    """

    left_eye_open: float = 0.6
    right_eye_open: float = 0.6

    gaze_x: float = 0.0
    gaze_y: float = 0.0

    left_brow_height: float = 0.0
    right_brow_height: float = 0.0
    left_brow_tilt: float = 0.0
    right_brow_tilt: float = 0.0

    mouth_open: float = 0.0
    mouth_width: float = 0.5
    mouth_roundness: float = 0.0
    mouth_compression: float = 0.0
    mouth_curvature: float = 0.0

    tracking_valid: bool = False
    measured_at: float = 0.0

    def __post_init__(self) -> None:
        for name in (
            "left_eye_open",
            "right_eye_open",
            "mouth_open",
            "mouth_width",
            "mouth_roundness",
            "mouth_compression",
        ):
            _check_unit(getattr(self, name), name)

        for name in (
            "gaze_x",
            "gaze_y",
            "left_brow_height",
            "right_brow_height",
            "left_brow_tilt",
            "right_brow_tilt",
            "mouth_curvature",
        ):
            _check_signed(getattr(self, name), name)

        if not isfinite(self.measured_at) or self.measured_at < 0.0:
            raise ValueError("measured_at must be finite and non-negative")


def neutral_state(*, measured_at: float = 0.0) -> ExpressionState:
    return ExpressionState(measured_at=measured_at)


def _check_unit(value: float, name: str) -> None:
    if not isfinite(value) or not 0.0 <= value <= 1.0:
        raise ValueError(f"{name} must be between 0 and 1")


def _check_signed(value: float, name: str) -> None:
    if not isfinite(value) or not -1.0 <= value <= 1.0:
        raise ValueError(f"{name} must be between -1 and 1")
