from __future__ import annotations

import tomllib
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class TrackerSettings:
    model: Path
    calibration_seconds: float = 1.0


@dataclass(frozen=True, slots=True)
class CameraSettings:
    width: int = 1280
    height: int = 720
    fps: int = 30
    mirror: bool = True


@dataclass(frozen=True, slots=True)
class Tuning:
    gaze_gain: float = 3.25
    brow_height_gain: float = 6.0
    brow_tilt_gain: float = 3.5
    mouth_open_range: float = 0.035
    mouth_width_range: float = 0.30
    mouth_roundness_range: float = 0.06
    mouth_curvature_range: float = 0.15


@dataclass(frozen=True, slots=True)
class Smoothing:
    eyes: float = 0.55
    gaze: float = 0.35
    brows: float = 0.70
    mouth: float = 0.45


@dataclass(frozen=True, slots=True)
class Config:
    tracker: TrackerSettings
    camera: CameraSettings = CameraSettings()
    tuning: Tuning = Tuning()
    smoothing: Smoothing = Smoothing()


def load_config(path: Path) -> Config:
    with path.open("rb") as handle:
        data = tomllib.load(handle)

    tracker = data.get("tracker", {})
    if "model" not in tracker:
        raise ValueError("[tracker].model is required")

    config = Config(
        tracker=TrackerSettings(
            model=Path(tracker["model"]),
            calibration_seconds=float(tracker.get("calibration_seconds", 1.0)),
        ),
        camera=CameraSettings(**data.get("camera", {})),
        tuning=Tuning(**data.get("tuning", {})),
        smoothing=Smoothing(**data.get("smoothing", {})),
    )
    _validate(config)
    return config


def _validate(config: Config) -> None:
    if config.tracker.calibration_seconds <= 0:
        raise ValueError("calibration_seconds must be positive")

    if config.camera.width <= 0 or config.camera.height <= 0 or config.camera.fps <= 0:
        raise ValueError("camera width, height and fps must be positive")

    for name in ("eyes", "gaze", "brows", "mouth"):
        value = getattr(config.smoothing, name)
        if not 0.0 <= value <= 1.0:
            raise ValueError(f"smoothing.{name} must be between 0 and 1")
