from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

import cv2

from .config import load_config
from .terminal import CLEAR, HIDE_CURSOR, HOME, RESET, SHOW_CURSOR, render
from .tracker import FaceTracker


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Generic facial-expression tracker for protogen control systems."
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=Path("config.toml"),
        help="Path to config.toml",
    )

    source = parser.add_mutually_exclusive_group()
    source.add_argument("--camera", type=int, default=0, help="OpenCV camera index")
    source.add_argument("--video", type=Path, help="Prerecorded video file")

    return parser


def main() -> int:
    args = build_parser().parse_args()

    try:
        config = load_config(args.config)
        tracker = FaceTracker(config)
        tracker.start()
    except Exception as exc:
        print(f"startup error: {exc}", file=sys.stderr)
        return 2

    capture = (
        cv2.VideoCapture(str(args.video))
        if args.video is not None
        else cv2.VideoCapture(args.camera)
    )

    if not capture.isOpened():
        tracker.close()
        print("unable to open input", file=sys.stderr)
        return 2

    if args.video is None:
        capture.set(cv2.CAP_PROP_FRAME_WIDTH, config.camera.width)
        capture.set(cv2.CAP_PROP_FRAME_HEIGHT, config.camera.height)
        capture.set(cv2.CAP_PROP_FPS, config.camera.fps)
        capture.set(cv2.CAP_PROP_BUFFERSIZE, 1)

    frame_interval = 1.0 / config.camera.fps

    sys.stdout.write(CLEAR + HOME + HIDE_CURSOR)
    sys.stdout.flush()

    try:
        while True:
            started = time.monotonic()
            ok, frame = capture.read()
            if not ok:
                break

            if config.camera.mirror:
                frame = cv2.flip(frame, 1)

            state = tracker.update(frame, measured_at=started)

            sys.stdout.write(HOME)
            sys.stdout.write(render(state, calibrated=tracker.calibrated))
            sys.stdout.flush()

            if args.video is not None:
                elapsed = time.monotonic() - started
                if elapsed < frame_interval:
                    time.sleep(frame_interval - elapsed)

    except KeyboardInterrupt:
        pass
    finally:
        capture.release()
        tracker.close()
        sys.stdout.write(RESET + SHOW_CURSOR + "\n")
        sys.stdout.flush()

    return 0
