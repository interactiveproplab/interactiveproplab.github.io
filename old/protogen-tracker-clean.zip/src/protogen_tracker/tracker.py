from __future__ import annotations

import time
from dataclasses import dataclass
from importlib import import_module
from math import hypot
from pathlib import Path
from typing import Any

import cv2
import numpy as np

from .config import Config
from .models import ExpressionState, neutral_state


@dataclass(frozen=True, slots=True)
class Landmark:
    x: float
    y: float


@dataclass(frozen=True, slots=True)
class Measurements:
    left_eye_open: float
    right_eye_open: float

    gaze_x: float
    gaze_y: float

    left_brow_height: float
    right_brow_height: float
    left_brow_tilt: float
    right_brow_tilt: float

    mouth_open: float
    mouth_width: float
    mouth_roundness_ratio: float
    mouth_compression: float
    mouth_curvature: float

    measured_at: float


@dataclass(frozen=True, slots=True)
class Baseline:
    left_eye_open: float
    right_eye_open: float
    gaze_x: float
    gaze_y: float
    left_brow_height: float
    right_brow_height: float
    left_brow_tilt: float
    right_brow_tilt: float
    mouth_open: float
    mouth_width: float
    mouth_roundness_ratio: float
    mouth_curvature: float


class FaceTracker:
    """MediaPipe-backed tracker that outputs only generic ExpressionState."""

    def __init__(self, config: Config) -> None:
        self.config = config
        self._landmarker: Any | None = None

        self._baseline: Baseline | None = None
        self._calibration_samples: list[Measurements] = []
        self._calibration_started = 0.0

        self._state = neutral_state()

    @property
    def calibrated(self) -> bool:
        return self._baseline is not None

    def start(self) -> None:
        model = self.config.tracker.model
        if not model.is_file():
            raise RuntimeError(f"MediaPipe model not found: {model}")

        python = import_module("mediapipe.tasks.python")
        vision = import_module("mediapipe.tasks.python.vision")

        options = vision.FaceLandmarkerOptions(
            base_options=python.BaseOptions(model_asset_path=str(model)),
            running_mode=vision.RunningMode.IMAGE,
            num_faces=1,
            min_face_detection_confidence=0.6,
            min_face_presence_confidence=0.6,
            min_tracking_confidence=0.6,
            output_face_blendshapes=False,
        )

        self._landmarker = vision.FaceLandmarker.create_from_options(options)
        self.recalibrate()

    def close(self) -> None:
        if self._landmarker is not None:
            self._landmarker.close()
            self._landmarker = None

    def recalibrate(self) -> None:
        self._baseline = None
        self._calibration_samples.clear()
        self._calibration_started = time.monotonic()

    def update(self, frame: np.ndarray[Any, Any], *, measured_at: float | None = None) -> ExpressionState:
        if self._landmarker is None:
            raise RuntimeError("FaceTracker.start() must be called first")

        timestamp = time.monotonic() if measured_at is None else measured_at
        raw = self._measure(frame, timestamp)

        if raw is None:
            self._state = _smooth(
                self._state,
                neutral_state(measured_at=timestamp),
                self.config,
            )
            return self._state

        if self._baseline is None:
            self._collect_calibration(raw)
            self._state = ExpressionState(
                tracking_valid=True,
                measured_at=timestamp,
            )
            return self._state

        target = _normalise(raw, self._baseline, self.config)
        self._state = _smooth(self._state, target, self.config)
        return self._state

    def _measure(self, frame: np.ndarray[Any, Any], measured_at: float) -> Measurements | None:
        assert self._landmarker is not None

        mp = import_module("mediapipe")
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
        result = self._landmarker.detect(image)

        if not result.face_landmarks:
            return None

        points = [Landmark(p.x, p.y) for p in result.face_landmarks[0]]
        return _measure_landmarks(points, measured_at)

    def _collect_calibration(self, raw: Measurements) -> None:
        self._calibration_samples.append(raw)

        if time.monotonic() - self._calibration_started < self.config.tracker.calibration_seconds:
            return

        values = self._calibration_samples
        self._baseline = Baseline(
            left_eye_open=_mean(values, "left_eye_open"),
            right_eye_open=_mean(values, "right_eye_open"),
            gaze_x=_mean(values, "gaze_x"),
            gaze_y=_mean(values, "gaze_y"),
            left_brow_height=_mean(values, "left_brow_height"),
            right_brow_height=_mean(values, "right_brow_height"),
            left_brow_tilt=_mean(values, "left_brow_tilt"),
            right_brow_tilt=_mean(values, "right_brow_tilt"),
            mouth_open=_mean(values, "mouth_open"),
            mouth_width=_mean(values, "mouth_width"),
            mouth_roundness_ratio=_mean(values, "mouth_roundness_ratio"),
            mouth_curvature=_mean(values, "mouth_curvature"),
        )


def _measure_landmarks(points: list[Landmark], measured_at: float) -> Measurements:
    face_width = _distance(points[234], points[454])

    left_eye_open = _ratio(
        _distance(points[159], points[145]),
        _distance(points[33], points[133]),
    )
    right_eye_open = _ratio(
        _distance(points[386], points[374]),
        _distance(points[362], points[263]),
    )

    mouth_width = (
        (_distance(points[61], points[291]) + _distance(points[78], points[308]))
        / 2.0
        / max(face_width, 1e-9)
    )
    mouth_open = _ratio(_distance(points[13], points[14]), face_width)
    mouth_roundness_ratio = mouth_open / max(mouth_width, 1e-9)
    mouth_compression = _clamp(1.0 - mouth_open * 18.0, 0.0, 1.0)

    left_brow_height = _brow_height(
        points[70], points[105], points[33], points[133], face_width
    )
    right_brow_height = _brow_height(
        points[300], points[334], points[362], points[263], face_width
    )
    left_brow_tilt = _brow_tilt(points[70], points[105], points[33], points[133])
    right_brow_tilt = _brow_tilt(points[300], points[334], points[362], points[263])

    gaze_x = 0.0
    gaze_y = 0.0
    if len(points) > 477:
        left_iris = _average_point(points, (468, 469, 470, 471, 472))
        right_iris = _average_point(points, (473, 474, 475, 476, 477))

        gaze_x = _average(
            _relative_interval(left_iris.x, points[33].x, points[133].x),
            _relative_interval(right_iris.x, points[362].x, points[263].x),
        )
        gaze_y = _average(
            _relative_interval(left_iris.y, points[159].y, points[145].y),
            _relative_interval(right_iris.y, points[386].y, points[374].y),
        )

    corner_y = (points[61].y + points[291].y) / 2.0
    mouth_curvature = _clamp(
        (points[13].y - corner_y) / max(face_width * 0.03, 1e-9),
        -1.0,
        1.0,
    )

    return Measurements(
        left_eye_open=left_eye_open,
        right_eye_open=right_eye_open,
        gaze_x=gaze_x,
        gaze_y=gaze_y,
        left_brow_height=left_brow_height,
        right_brow_height=right_brow_height,
        left_brow_tilt=left_brow_tilt,
        right_brow_tilt=right_brow_tilt,
        mouth_open=mouth_open,
        mouth_width=mouth_width,
        mouth_roundness_ratio=mouth_roundness_ratio,
        mouth_compression=mouth_compression,
        mouth_curvature=mouth_curvature,
        measured_at=measured_at,
    )


def _normalise(raw: Measurements, base: Baseline, config: Config) -> ExpressionState:
    tune = config.tuning

    eye_l = _clamp(raw.left_eye_open / max(base.left_eye_open, 1e-9), 0.0, 1.0)
    eye_r = _clamp(raw.right_eye_open / max(base.right_eye_open, 1e-9), 0.0, 1.0)

    mouth_open = _clamp(
        (raw.mouth_open - base.mouth_open) / max(tune.mouth_open_range, 1e-9),
        0.0,
        1.0,
    )

    stretch = (
        raw.mouth_width / max(base.mouth_width, 1e-9) - 1.0
    ) / max(tune.mouth_width_range, 1e-9)
    mouth_width = _clamp(0.5 + 0.5 * stretch, 0.0, 1.0)

    mouth_roundness = _clamp(
        (raw.mouth_roundness_ratio - base.mouth_roundness_ratio)
        / max(tune.mouth_roundness_range, 1e-9),
        0.0,
        1.0,
    )

    mouth_compression = _clamp(
        1.0 - raw.mouth_open / max(base.mouth_open, 1e-9),
        0.0,
        1.0,
    )

    mouth_curvature = _clamp(
        (raw.mouth_curvature - base.mouth_curvature)
        / max(tune.mouth_curvature_range, 1e-9),
        -1.0,
        1.0,
    )

    return ExpressionState(
        left_eye_open=eye_l,
        right_eye_open=eye_r,
        gaze_x=_clamp((raw.gaze_x - base.gaze_x) * tune.gaze_gain, -1.0, 1.0),
        gaze_y=_clamp((raw.gaze_y - base.gaze_y) * tune.gaze_gain, -1.0, 1.0),
        left_brow_height=_clamp(
            (raw.left_brow_height - base.left_brow_height) / 0.03 * tune.brow_height_gain,
            -1.0,
            1.0,
        ),
        right_brow_height=_clamp(
            (raw.right_brow_height - base.right_brow_height) / 0.03 * tune.brow_height_gain,
            -1.0,
            1.0,
        ),
        left_brow_tilt=_clamp(
            (raw.left_brow_tilt - base.left_brow_tilt) * tune.brow_tilt_gain,
            -1.0,
            1.0,
        ),
        right_brow_tilt=_clamp(
            (raw.right_brow_tilt - base.right_brow_tilt) * tune.brow_tilt_gain,
            -1.0,
            1.0,
        ),
        mouth_open=mouth_open,
        mouth_width=mouth_width,
        mouth_roundness=mouth_roundness,
        mouth_compression=mouth_compression,
        mouth_curvature=mouth_curvature,
        tracking_valid=True,
        measured_at=raw.measured_at,
    )


def _smooth(previous: ExpressionState, target: ExpressionState, config: Config) -> ExpressionState:
    smooth = config.smoothing

    def blend(a: float, b: float, alpha: float) -> float:
        return a + (b - a) * alpha

    return ExpressionState(
        left_eye_open=blend(previous.left_eye_open, target.left_eye_open, smooth.eyes),
        right_eye_open=blend(previous.right_eye_open, target.right_eye_open, smooth.eyes),
        gaze_x=blend(previous.gaze_x, target.gaze_x, smooth.gaze),
        gaze_y=blend(previous.gaze_y, target.gaze_y, smooth.gaze),
        left_brow_height=blend(previous.left_brow_height, target.left_brow_height, smooth.brows),
        right_brow_height=blend(previous.right_brow_height, target.right_brow_height, smooth.brows),
        left_brow_tilt=blend(previous.left_brow_tilt, target.left_brow_tilt, smooth.brows),
        right_brow_tilt=blend(previous.right_brow_tilt, target.right_brow_tilt, smooth.brows),
        mouth_open=blend(previous.mouth_open, target.mouth_open, smooth.mouth),
        mouth_width=blend(previous.mouth_width, target.mouth_width, smooth.mouth),
        mouth_roundness=blend(previous.mouth_roundness, target.mouth_roundness, smooth.mouth),
        mouth_compression=blend(previous.mouth_compression, target.mouth_compression, smooth.mouth),
        mouth_curvature=blend(previous.mouth_curvature, target.mouth_curvature, smooth.mouth),
        tracking_valid=target.tracking_valid,
        measured_at=target.measured_at,
    )


def _distance(a: Landmark, b: Landmark) -> float:
    return hypot(b.x - a.x, b.y - a.y)


def _ratio(a: float, b: float) -> float:
    return 0.0 if abs(b) < 1e-9 else a / b


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def _average(*values: float) -> float:
    return sum(values) / len(values)


def _average_point(points: list[Landmark], indices: tuple[int, ...]) -> Landmark:
    return Landmark(
        _average(*(points[i].x for i in indices)),
        _average(*(points[i].y for i in indices)),
    )


def _relative_interval(value: float, first: float, second: float) -> float:
    low, high = sorted((first, second))
    span = high - low
    if span < 1e-9:
        return 0.0
    return _clamp(((value - low) / span - 0.5) * 2.0, -1.0, 1.0)


def _brow_height(
    brow_a: Landmark,
    brow_b: Landmark,
    eye_a: Landmark,
    eye_b: Landmark,
    face_width: float,
) -> float:
    brow_centre = Landmark((brow_a.x + brow_b.x) / 2.0, (brow_a.y + brow_b.y) / 2.0)
    dx = eye_b.x - eye_a.x
    dy = eye_b.y - eye_a.y
    length = hypot(dx, dy)
    if length < 1e-9:
        return 0.0

    perpendicular = -(
        dx * (brow_centre.y - eye_a.y) - dy * (brow_centre.x - eye_a.x)
    ) / length
    return _ratio(perpendicular, face_width)


def _brow_tilt(
    brow_a: Landmark,
    brow_b: Landmark,
    eye_a: Landmark,
    eye_b: Landmark,
) -> float:
    def slope(a: Landmark, b: Landmark) -> float:
        dx = b.x - a.x
        return 0.0 if abs(dx) < 1e-9 else (b.y - a.y) / dx

    return _clamp((slope(brow_a, brow_b) - slope(eye_a, eye_b)) / 0.25, -1.0, 1.0)


def _mean(values: list[Measurements], field: str) -> float:
    return sum(float(getattr(v, field)) for v in values) / len(values)
