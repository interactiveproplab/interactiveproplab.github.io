from __future__ import annotations

from .models import ExpressionState


ACCENT = "\x1b[38;2;255;107;94m"
DIM = "\x1b[38;2;143;51;45m"
RESET = "\x1b[0m"
HOME = "\x1b[H"
CLEAR = "\x1b[2J"
HIDE_CURSOR = "\x1b[?25l"
SHOW_CURSOR = "\x1b[?25h"


def render(state: ExpressionState, *, calibrated: bool) -> str:
    if not calibrated:
        status = f"{DIM}CALIBRATING — HOLD NEUTRAL{RESET}"
    elif state.tracking_valid:
        status = f"{ACCENT}LOCKED{RESET}"
    else:
        status = f"{DIM}LOST{RESET}"

    return f"""\
{ACCENT}INTERACTIVE PROP LAB{RESET}
{DIM}LIVE EXPRESSION TRACKING{RESET}

TRACKING          {status}

LEFT EYE          {_bar(state.left_eye_open)}  {state.left_eye_open:5.2f}
RIGHT EYE         {_bar(state.right_eye_open)}  {state.right_eye_open:5.2f}

LEFT BROW         {_signed(state.left_brow_height)}  {state.left_brow_height:+5.2f}
RIGHT BROW        {_signed(state.right_brow_height)}  {state.right_brow_height:+5.2f}

LEFT BROW TILT    {_signed(state.left_brow_tilt)}  {state.left_brow_tilt:+5.2f}
RIGHT BROW TILT   {_signed(state.right_brow_tilt)}  {state.right_brow_tilt:+5.2f}

GAZE X            {_signed(state.gaze_x)}  {state.gaze_x:+5.2f}
GAZE Y            {_signed(state.gaze_y)}  {state.gaze_y:+5.2f}

MOUTH OPEN        {_bar(state.mouth_open)}  {state.mouth_open:5.2f}
MOUTH WIDTH       {_bar(state.mouth_width)}  {state.mouth_width:5.2f}
ROUNDNESS         {_bar(state.mouth_roundness)}  {state.mouth_roundness:5.2f}
COMPRESSION       {_bar(state.mouth_compression)}  {state.mouth_compression:5.2f}
CURVATURE         {_signed(state.mouth_curvature)}  {state.mouth_curvature:+5.2f}
"""


def _bar(value: float, width: int = 18) -> str:
    value = max(0.0, min(1.0, value))
    filled = round(value * width)
    return ACCENT + ("█" * filled) + DIM + ("░" * (width - filled)) + RESET


def _signed(value: float, width: int = 18) -> str:
    value = max(-1.0, min(1.0, value))
    half = width // 2
    magnitude = round(abs(value) * half)

    left = ["░"] * half
    right = ["░"] * half

    if value < 0:
        for i in range(half - magnitude, half):
            left[i] = "█"
    else:
        for i in range(magnitude):
            right[i] = "█"

    return DIM + "".join(left) + RESET + "│" + ACCENT + "".join(right) + RESET
