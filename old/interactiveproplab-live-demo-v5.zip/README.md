# Interactive Prop Lab — live demo v5

Upload:

- `index.html`
- `style.css`
- `face-demo-v5.js`

Delete older demo JS files.

## UI change

The demo is now a proper input/output rig:

- left: webcam + sparse tracking overlay;
- right: simulated 64×32 protogen LED matrix.

The LED matrix is not decorative. It is rendered from the same normalised state:

- independent eye openness controls eye height;
- gaze moves the eye/pupil response;
- independent brow height and tilt move each brow;
- mouth opening changes matrix mouth height;
- mouth width changes span;
- curvature changes smile/frown shape.

The right-hand matrix is visible even before the camera starts, so the demo reads as
a character-control system instead of a webcam page.

MediaPipe runtime remains the v4 pinned 0.10.32 no-SIMD configuration.
