# Interactive Prop Lab — live demo v8

v8 preserves the v7 layout exactly.

Upload:

- `index.html`
- `style.css`
- `face-demo-v8.js`
- `face-worker-v8.js`

Delete the old Face Mesh script/file.

## Detector fix

The v7 legacy Face Mesh solution failed because it requires a WebGL canvas
context when video frames are passed in.

v8 uses the current MediaPipe Tasks Vision 1.0.0 stack instead:

- `@mediapipe/tasks-vision@1.0.0`
- CPU delegate
- WASM runtime
- Face Landmarker `.task` model
- `ImageBitmap` frames transferred to a module Worker
- IMAGE mode detection, so there is no MediaPipe WebGL video path
- 478 face landmarks returned to the existing calibration/mapping code

The HTML/CSS demo layout is unchanged from v7.
