# Interactive Prop Lab — live facial demo v3

Upload these three files to the root of the GitHub Pages repository:

- `index.html`
- `style.css`
- `face-demo-v3.js`

Delete the old demo scripts (`live-demo.js`, `tracker-demo-v2.js`,
`tracker-worker-v2.js`) so there is no ambiguity.

## Important change

This version intentionally does **not** use MediaPipe `detectForVideo()`.

It runs Face Landmarker in IMAGE mode at a throttled rate against an off-screen
canvas snapshot of the webcam. The site then performs its own neutral calibration,
normalisation and smoothing.

That is enough for the portfolio demo and removes the video-mode timestamp/worker
path that was causing the previous failures.

## Visual design

There is no numeric diagnostics dashboard.

The live camera is the demo. Only the eyes, brows, mouth and iris points used for
control are drawn as a coral overlay. A small four-signal strip shows which control
groups are active.
