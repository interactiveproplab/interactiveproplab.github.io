# Interactive Prop Lab — live demo v6

Upload:

- `index.html`
- `style.css`
- `face-demo-v6.js`

Delete older `face-demo-v*.js` files.

v6 keeps the v5 camera → 64×32 protogen LED matrix UI, but replaces
MediaPipe Tasks Vision with the older Face Mesh streaming browser solution.

Pinned runtime:
`@mediapipe/face_mesh@0.4.1633559619`

Face Mesh is configured with:
- one face;
- `refineLandmarks: true` for iris landmarks;
- 0.45 detection confidence;
- 0.45 tracking confidence.

Frames go through the intended streaming API:
`faceMesh.send({ image: video })`.

The expression normalization and LED matrix mapping are unchanged.
