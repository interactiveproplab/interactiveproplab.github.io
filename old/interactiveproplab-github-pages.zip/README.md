# Interactive Prop Lab v6

Changes:
- Hero reduced to a compact intro block.
- Main headline reduced substantially.
- Build/parallax section centered.
- `03 / BUILD PROCESS` grows from the center rather than the left edge.
- Build steps made slightly larger and more substantial.
- Overall section spacing increased slightly.

Upload `index.html` and `style.css` to the GitHub Pages repo root.
