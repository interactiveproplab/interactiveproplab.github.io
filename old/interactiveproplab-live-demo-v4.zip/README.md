# Interactive Prop Lab — live facial demo v4

Upload these three files to the GitHub Pages repo root:

- `index.html`
- `style.css`
- `face-demo-v4.js`

Delete all previous demo JS files.

## What v4 fixes

The previous build failed during MediaPipe WASM initialization with:

`ModuleFactory not set.`

v4 pins the browser runtime to MediaPipe Tasks Vision 0.10.32 and bypasses
automatic WASM resolution. It supplies an explicit, version-matched no-SIMD
loader/binary pair directly to `FaceLandmarker.createFromOptions()`.

The actual pair is:

- `vision_wasm_nosimd_internal.js`
- `vision_wasm_nosimd_internal.wasm`

Both come from `@mediapipe/tasks-vision@0.10.32`.
