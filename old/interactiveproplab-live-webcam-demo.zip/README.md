# Interactive Prop Lab — live browser demo

Upload these three files to the root of `interactiveproplab.github.io`:

- `index.html`
- `style.css`
- `live-demo.js`

No build step is required.

## What changed

The old prerecorded tracking placeholder is now a real browser demo.

When the visitor clicks **TRY LIVE TRACKING**:

1. the browser requests camera permission (video only);
2. MediaPipe Face Landmarker loads in the browser;
3. the first second of a visible neutral face becomes the baseline;
4. eye openness, brows, gaze and mouth geometry update live;
5. **STOP CAMERA** stops every MediaStream track.

The browser demo uses the same landmark geometry / neutral-baseline approach as the standalone tracker.

## Hosting

This is intended for GitHub Pages over HTTPS.

The MediaPipe JavaScript/WASM runtime is loaded from jsDelivr and the official Face Landmarker model is loaded from Google's MediaPipe model storage. Camera frames themselves are processed by the browser and are not posted to Interactive Prop Lab.
