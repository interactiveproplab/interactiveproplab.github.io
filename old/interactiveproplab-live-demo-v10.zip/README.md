# Interactive Prop Lab — live demo v10

v10 starts from the good v7 layout and changes only the detector backend.

Upload:

- `index.html`
- `style.css`
- `face-demo-v10.js`

Delete every older `face-demo-v*.js` and `face-worker-v*.js`.

## Detector architecture

The page now uses TensorFlow.js Face Landmarks Detection with the pure-JavaScript
CPU backend.

Loaded packages:

- @tensorflow/tfjs-core 4.22.0
- @tensorflow/tfjs-converter 4.22.0
- @tensorflow/tfjs-backend-cpu 4.22.0
- @tensorflow-models/face-detection 1.0.3
- @tensorflow-models/face-landmarks-detection 1.0.6

Not loaded:

- MediaPipe browser runtime
- TensorFlow.js WASM backend
- TensorFlow.js WebGL backend
- Web workers

The detector forces:

`tf.setBackend("cpu")`

and verifies:

`tf.getBackend() === "cpu"`.

This means there is no WebGL context creation and no WebAssembly ModuleFactory
loader involved.

The tradeoff is speed, so the browser demo runs at a deliberately conservative
~7 detection updates per second with a 640×480 camera request. The existing
smoothing continues to animate the protogen output between updates.

The v7 layout and CSS are preserved.
