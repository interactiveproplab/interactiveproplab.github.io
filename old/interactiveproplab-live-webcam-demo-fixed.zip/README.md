# Interactive Prop Lab — live tracker v2

Replace the files in the GitHub Pages repo root with:

- `index.html`
- `style.css`
- `tracker-demo-v2.js`
- `tracker-worker-v2.js`

The new filenames are deliberate so an older cached `live-demo.js` cannot keep running.

The live demo now follows MediaPipe's current browser sample pattern more closely:

- the webcam frame is converted to an `ImageBitmap`;
- the bitmap is transferred to a module Worker;
- Face Landmarker runs in `VIDEO` mode in the Worker;
- the model is fetched as a buffer before `createFromOptions`;
- timestamps are monotonically increasing;
- CPU is used deliberately for compatibility;
- only the returned landmark array comes back to the page.

The visible UI is also simplified: full camera view plus a small reactive control face.
