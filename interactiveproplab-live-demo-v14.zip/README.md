# Interactive Prop Lab — live demo v14

This is the first build that follows the current official MediaPipe web-sample
deployment pattern instead of loading the ML runtime piecemeal from CDNs.

## Why the project now has a build step

The current MediaPipe web sample:

- installs `@mediapipe/tasks-vision` as a package;
- copies the package's WASM directory into the deployed site's own `/wasm`;
- bundles the worker/imports with Vite;
- transfers `ImageBitmap` webcam frames to a module worker;
- calls `detectForVideo(bitmap, timestampMs)` there.

v14 does the same thing, while retaining the Interactive Prop Lab v12/v13
camera + protogen matrix UI and calibration/mapping.

## Deploy

Commit the contents of this directory to the repository root.

Then in GitHub:

1. Open **Settings → Pages**.
2. Set **Source** to **GitHub Actions**.
3. Push to `main`.
4. Open the **Actions** tab and confirm `Deploy Interactive Prop Lab` succeeds.

The workflow automatically:

1. installs the pinned dependencies;
2. copies the exact package WASM files to `public/wasm`;
3. downloads `face_landmarker.task` to `public/models`;
4. bundles the app with Vite;
5. deploys `dist/` to GitHub Pages.

## Runtime

Pinned:
- `@mediapipe/tasks-vision` 1.0.1
- Vite 8.2.0

Face Landmarker:
- CPU delegate
- VIDEO running mode
- module Worker
- `createImageBitmap(video)`
- monotonically increasing timestamps
- local/same-origin WASM
- local/same-origin face model

No runtime ML CDN URLs remain in the browser app.
